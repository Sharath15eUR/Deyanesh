#!/bin/bash

# Global variables for storing command-line arguments
directory=""
keyword=""
file=""

# Function to display an error message and log it
log_error() {
  echo "$1"  # Display the error message in the terminal
  echo "$1" >> errors.log  # Append the error message to errors.log
}

# Recursive function to search for files containing the keyword
search_files() {
  local dir=$1
  local keyword=$2
  
  # Loop through all files and directories
  for item in "$dir"/*; do
    if [ -d "$item" ]; then
      # Recursively search in subdirectories
      search_files "$item" "$keyword"
    elif [ -f "$item" ]; then
      # Search the file for the keyword
      if grep -q "$keyword" "$item"; then
        echo "Keyword '$keyword' found in: $item"
      fi
    fi
  done
}

# Validate the inputs
validate_inputs() {
  if [[ -n "$directory" && ! -d "$directory" ]]; then
    log_error "Invalid directory: $directory"
    exit 1
  fi
  if [[ -z "$keyword" ]]; then
    log_error "Keyword cannot be empty."
    exit 1
  fi
}

# Display the help menu using a here document
display_help() {
  cat <<EOF
Usage: $0 [options]
Options:
  -d <directory>   Directory to search.
  -k <keyword>     Keyword to search for.
  -f <file>        File to search for the keyword directly.
  --help           Display this help menu.
EOF
}

# Search for a keyword in a specific file using a here string
search_in_file() {
  local file=$1
  local keyword=$2
  if grep -q "$keyword" <<< "$file"; then
    echo "Keyword '$keyword' found in file: $file"
  else
    echo "Keyword '$keyword' not found in file: $file"
  fi
}

# Parse the command-line arguments using getopts
while getopts "d:k:f:" opt; do
  case "$opt" in
    d) directory=$OPTARG ;;
    k) keyword=$OPTARG ;;
    f) file=$OPTARG ;;
    *) display_help; exit 1 ;;
  esac
done

# Handle the --help option
if [[ "$1" == "--help" ]]; then
  display_help
  exit 0
fi

# Validate inputs if a directory or keyword is provided
if [[ -n "$directory" || -n "$file" ]]; then
  validate_inputs
fi

# Perform the search based on the provided arguments
if [[ -n "$directory" && -n "$keyword" ]]; then
  # Recursively search a directory for the keyword
  search_files "$directory" "$keyword"
elif [[ -n "$file" && -n "$keyword" ]]; then
  # Search a specific file for the keyword
  search_in_file "$file" "$keyword"
else
  log_error "Invalid usage. Please provide both a directory/file and a keyword."
  display_help
  exit 1
fi
