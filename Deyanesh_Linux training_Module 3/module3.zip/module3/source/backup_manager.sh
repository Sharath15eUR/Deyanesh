#!/bin/bash

# Check if the correct number of arguments are passed
if [ $# -ne 3 ]; then
    echo "Please provide all required parameters: source directory, backup directory, and file extension."
    exit 1
fi

# Assign arguments to variables with new names
source_directory=$1
backup_directory=$2
file_extension=$3

# Check if the source directory exists
if [ ! -d "$source_directory" ]; then
    echo "Source directory $source_directory does not exist."
    exit 1 
fi

# Check if the backup directory exists, if not, try to create it
if [ ! -d "$backup_directory" ]; then
    mkdir -p "$backup_directory"
    if [ $? -ne 0 ]; then
        echo "Unable to create the backup directory $backup_directory."
        exit 1
    fi
fi

# Initialize a counter to track the number of files backed up
export BACKUP_FILE_COUNT=0

# Store files with the specified extension in an array
files_to_backup=("$source_directory"/*"$file_extension")

# Check if there are no files matching the extension
if [ ${#files_to_backup[@]} -eq 0 ]; then
    echo "No files matching the extension $file_extension found in $source_directory."
    exit 1
fi

# Initialize variable to store total size of files being backed up
total_size=0

# Print the names and sizes of the files to be backed up
for file in "${files_to_backup[@]}"; do
    if [ -f "$file" ]; then
        file_size=$(stat -c "%s" "$file")
        total_size=$((total_size + file_size))
        echo "$(basename "$file") - $file_size bytes"
    fi
done

# Perform the backup operation
for file in "${files_to_backup[@]}"; do
    if [ -f "$file" ]; then
        backup_file="$backup_directory"/"$(basename "$file")"
        
        # If the file already exists in the backup directory, check if it's older
        if [ -f "$backup_file" ]; then
            if [ "$file" -nt "$backup_file" ]; then
                cp -p "$file" "$backup_file"
                BACKUP_FILE_COUNT=$((BACKUP_FILE_COUNT + 1))
            fi
        else
            cp -p "$file" "$backup_file"
            BACKUP_FILE_COUNT=$((BACKUP_FILE_COUNT + 1))
        fi
    fi
done

# Generate the backup summary report
report_file="$backup_directory/backup_summary.log"

echo "Backup Summary Report" > "$report_file"
echo "Total Files Backed Up: $BACKUP_FILE_COUNT" >> "$report_file"
echo "Total Size of Backed Up Files: $total_size bytes" >> "$report_file"
echo "Backup Directory Path: $backup_directory" >> "$report_file"

# Display the content of the backup report
cat "$report_file"

# Exit the script successfully
exit 0
